﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _15_A
{
    public class FrequenciesForValue
    {
        public int Count = 1;
        public double RelativeFrequency;
        public double Percentage;
    }
}
