﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _15_A
{
    public partial class Form1 : Form
    {

        // graphics
        public Bitmap b;
        public Graphics g;
        public Font SmallFont = new Font("Calibri", 10f, FontStyle.Regular, GraphicsUnit.Pixel);
        Color[] colors = { Color.Blue, Color.Red, Color.Green, Color.Purple, Color.Aquamarine, Color.Brown, Color.Orange, Color.Cyan, Color.Magenta, Color.Lavender, Color.Coral };

        // viewport
        public Rectangle Viewport;

        // window'
        public decimal MinX_Window = 0;
        public decimal MaxX_Window; // assigned by number of trials
        public decimal MinY_Window = 0;
        public decimal MaxY_Window;
        public decimal RangeX;
        public decimal RangeY;

        int numOfObservations;
        decimal maxValue;
        decimal minValue;
        decimal startingPoint;
        decimal intervalSize;

        public Form1()
        {
            InitializeComponent();
        }

        private void InitializeGraphics()
        {
            b = new Bitmap(this.pictureBox1.Width, this.pictureBox1.Height);
            g = Graphics.FromImage(b);
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            g.TextRenderingHint = System.Drawing.Text.TextRenderingHint.AntiAlias;
            Viewport = new Rectangle(5, 5, this.pictureBox1.Width - 10, this.pictureBox1.Height - 10);

            this.MaxX_Window = (decimal)numOfObservations;
            this.MaxY_Window = (decimal)numOfObservations;

            RangeX = MaxX_Window - MinX_Window;
            RangeY = MaxY_Window - MinY_Window;
        }

        private void startButton_Click(object sender, EventArgs e)
        {

            int.TryParse(this.observationsTextBox.Text, out numOfObservations);
            decimal.TryParse(this.maxTextBox.Text, out maxValue);
            decimal.TryParse(this.minTextBox.Text, out minValue);
            decimal.TryParse(this.startingPointTextBox.Text, out startingPoint);
            decimal.TryParse(this.intervalSizeTextBox.Text, out intervalSize);

            List<decimal> listOfObservations = new List<decimal>();

            //init graphics
            InitializeGraphics();

            //build list of observations
            listOfObservations = generateObservations(this.numOfObservations);

            //calculating distribution for historgram
            Dictionary<Interval, FrequenciesForValue>  distribution = UnivariateDistribution_ContinuousVariable(listOfObservations, intervalSize, startingPoint);

            //drawing histogram
            int max = 0;
            foreach (KeyValuePair<Interval, FrequenciesForValue> kvp in distribution)
            {
                if (distribution[kvp.Key].Count > max)
                    {
                        max = distribution[kvp.Key].Count;
                    }
            }
            float slotW = (this.pictureBox1.Width - 10) / (float)distribution.Count;
            float slotH = ( this.pictureBox1.Height / (float)max ) - 10;

            //drawing rectangle
            g.Clear(Color.Black);
            Pen rectanglePen = new Pen(Color.White, 2);
            g.DrawRectangle(rectanglePen, Viewport);

            //draw histogram
            int i = 0;
            foreach (KeyValuePair<Interval, FrequenciesForValue> kvp in distribution) {
                SolidBrush brush = new SolidBrush(Color.FromArgb(128, colors[i % colors.Length]));
                g.FillRectangle(brush, i * slotW + 5, pictureBox1.Height - 5 - kvp.Value.Count * slotH, slotW, kvp.Value.Count * slotH);
                i++;
            }

            //draw empirical cdf
            Pen pen = new Pen(Color.White, 3);
            int actualRF = 0;
            Point prevEndPoint = new Point(X_Viewport(0, Viewport, MinX_Window, RangeX), Y_Viewport(0, Viewport, MinY_Window, RangeY));
            foreach (KeyValuePair<Interval, FrequenciesForValue> kvp in distribution)
            {
                actualRF += kvp.Value.Count;
                // DRAWING P LINE
                int xStart = X_Viewport(kvp.Key.LowerEnd, Viewport, MinX_Window, RangeX);
                int xEnd = X_Viewport(kvp.Key.UpperEnd, Viewport, MinX_Window, RangeX);
                int y = Y_Viewport(actualRF, Viewport, MinY_Window, RangeY);
                g.DrawLine(pen, new Point(xStart, y), new Point(xEnd, y));
                //draw previous vertical segment
                g.DrawLine(pen, prevEndPoint, new Point(xStart, y));
                prevEndPoint.X = xEnd;
                prevEndPoint.Y = y;
            }



            this.pictureBox1.Image = b;


        }


        // X to x transformation'
        public int X_Viewport(decimal X_World, Rectangle Viewport, decimal MinX, decimal RangeX)
        {
            return (int)(Viewport.Left + Viewport.Width * (X_World - MinX) / RangeX);
        }

        // Y to y transformation'
        public int Y_Viewport(decimal Y_World, Rectangle Viewport, decimal MinY, decimal RangeY)
        {
            return (int)(Viewport.Top + Viewport.Height - Viewport.Height * (Y_World - MinY) / RangeY);
        }


        List<decimal> generateObservations(int numberOfObservations)
        {
            List<decimal> list = new List<decimal>();
            Random r = new Random();
            for (int i = 0; i < numberOfObservations; i++)
            {
                decimal next = (decimal)r.NextDouble();
                list.Add(Math.Round(minValue + (next * (maxValue - minValue)), 2));
            }
            list.Sort();
            return list;

        }

        private void Clear_Click(object sender, EventArgs e)
        {
            this.observationsTextBox.Clear();
            this.minTextBox.Clear();
            this.maxTextBox.Clear();
            this.intervalSizeTextBox.Clear();
            this.startingPointTextBox.Clear();

            this.numOfObservations = 0;
            this.MaxX_Window = 0;

            this.pictureBox1.Image = null;
        }

        Dictionary<Interval, FrequenciesForValue> UnivariateDistribution_ContinuousVariable(List<decimal> ListOfObservations, decimal IntervalSize, decimal StartingEndPoint)
        {
            var FrequencyDistribution = new Dictionary<Interval, FrequenciesForValue>();

            // First interval
            var Interval_X_0 = new Interval();
            Interval_X_0.LowerEnd = StartingEndPoint;
            Interval_X_0.UpperEnd = Interval_X_0.LowerEnd + IntervalSize;
            var ListOfIntervals_X = new List<Interval>();
            ListOfIntervals_X.Add(Interval_X_0);
            Interval Interval_Found_X;

            foreach (decimal d in ListOfObservations)
            {
                Interval_Found_X = null;
                Interval_Found_X = FindIntervalForValue(d, IntervalSize, ref ListOfIntervals_X);

                if (FrequencyDistribution.ContainsKey(Interval_Found_X))
                {
                    FrequencyDistribution[Interval_Found_X].Count += 1;
                }
                else
                {
                    FrequencyDistribution.Add(Interval_Found_X, new FrequenciesForValue());
                }
            }
            return FrequencyDistribution;
        }

        Interval FindIntervalForValue(decimal v, decimal IntervalSize, ref List<Interval> ListOfIntervals)
        {
            foreach (var Interval in ListOfIntervals)
            {
                if (Interval.ContainsValue(v))
                    return Interval;
            }

            if (v <= ListOfIntervals[0].LowerEnd)
            {
                do
                {
                    var NewLeftInterval = new Interval();
                    NewLeftInterval.UpperEnd = ListOfIntervals[0].LowerEnd;
                    NewLeftInterval.LowerEnd = NewLeftInterval.UpperEnd - IntervalSize;
                    ListOfIntervals.Insert(0, NewLeftInterval);
                    if (NewLeftInterval.ContainsValue(v))
                        return NewLeftInterval;
                }
                while (true);
            }
            else if (v > ListOfIntervals[ListOfIntervals.Count - 1].UpperEnd)
            {
                do
                {
                    var NewRightInterval = new Interval();
                    NewRightInterval.LowerEnd = ListOfIntervals[ListOfIntervals.Count - 1].UpperEnd;
                    NewRightInterval.UpperEnd = NewRightInterval.LowerEnd + IntervalSize;
                    ListOfIntervals.Add(NewRightInterval);
                    if (NewRightInterval.ContainsValue(v))
                        return NewRightInterval;
                }
                while (true);
            }

            return default;
        }
    }
}
