﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _15_A
{
    class Interval
    {
        public decimal LowerEnd;
        public decimal UpperEnd;

        public bool ContainsValue(decimal v)
        {
            return v > LowerEnd && v <= UpperEnd;
        }
    }
}
